#include <ros/ros.h>
#include <geometry_msgs/Twist.h> //include velocity msg to publish velocity 
#include <projet_minilab/Arbre.hpp>

//To print use ROS_INFO()

class Minilab
{
public:
  Minilab();

private:
  void minCallback(); //CallBack function that will get called when a new message arrives on the chatter topic 
  
  ros::NodeHandle nh_;

  int linear_, angular_;
  double l_scale_, a_scale_;
  ros::Publisher twist_pub_; // variable to use to publish with the node handler
  //ros::Subscriber joy_sub_;// variable to use to subscribe 
  
};

// 
Minilab::Minilab():
  linear_(1),
  angular_(2)
{

  //Node Handler parameters configuration  
  nh_.param("axis_linear", linear_, linear_);
  nh_.param("axis_angular", angular_, angular_);
  nh_.param("scale_angular", a_scale_, a_scale_);
  nh_.param("scale_linear", l_scale_, l_scale_);

  //tell to the master that a message of type "turtlesim::Velocity" will is going to be published on the topic
  twist_pub_ = nh_.advertise<geometry_msgs::Twist>("turtle1/cmd_vel", 3);


}

void Minilab::minCallback()

{
  
  geometry_msgs::Twist twist; 
  twist.angular.z = 0;
  twist.linear.x = 0;
  twist_pub_.publish(twist);
  
}


//// MAIN ////

int main(int argc, char** argv)
{

  
  ros::init(argc, argv, "Minilab"); //ros::init must be called before any other part of the ROS system( usage : ros::init(argc,argv,"node") )

  Minilab minilab;// sub function that configures the node handler,subscriber and publisher 
  
  Quadtree();
  
  //ros::spin(); // Used to loop while messages come and the CallBack function is called when a message arrives 
}

